from random import shuffle
from operator import itemgetter

deck = []
faces = ["A", "J", "Q", "K", "Joker"]


def createdeck():
    for i in range(4):
        for card in range(2, 11):
            deck.append(str(card))
        for card in range(len(faces)):
            deck.append(faces[card])
    return deck


Carddeck = createdeck()
shuffle(deck)
print(deck)


class player:
    def __init__(self, card=[], money=1000):
        self.card = card
        self.name = " "
        self.player_turn = " "
        self.cardvalues = []
        self.money = money
        self.reward = 0
        self.bet = 0

    def play(self):
        facesdict = {"A": 1, "J": 11, "Q": 12, "K": 13, "Joker": 14, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7,
                     "8": 8, "9": 9, "10": 10}
        self.player_turn = player_name
        while True:
            cardvalues_two = itemgetter(*secondhand)(facesdict)
            print("House: ", cardvalues_two)
            print(max(cardvalues_two))
            cardvalues_one = itemgetter(*firsthand)(facesdict)
            print(player_name,  cardvalues_one)
            print(max(cardvalues_one))
            if (max(cardvalues_one)) > (max(cardvalues_two)):
                print(player_name, " wins")
            elif (max(cardvalues_one)) == (max(cardvalues_two)):
                print("draw")
            else:
                print("House wins ")
            break


player_name = input("what is your name: ")
firsthand = [deck.pop(), deck.pop(), deck.pop()]
secondhand = [deck.pop(), deck.pop(), deck.pop()]
print("House: ", secondhand)
print(player_name, ": ", firsthand)

game = player(firsthand)
print(game.play())

again = input("want to play again: ?")
if again == "y":
    print(deck)
    print(game.play())
else:
    print("Good bye")
