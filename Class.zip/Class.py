class vehicle:

    def __init__(self, make, model, year, weight, tripsincemaintenance, needsmaintenance=False, ):
        self.tripsincemaintenance = tripsincemaintenance
        self.needsmaintenance = needsmaintenance
        self.make = make
        self.model = model
        self.year = year
        self.weight = weight

    # def settrip(self):
    # self.tripsincemaintenance = int(self.tripsincemaintenance) + 1

    def setmake(self, make1):
        self.make = make1

    def setmodel(self, model1):
        self.model = model1

    def setyear(self, year1):
        self.year = year1

    def setweight(self, weight1):
        self.weight = weight1

    def setrepair(self):
        self.needsmaintenance = 0


class car(vehicle):

    def __init__(self, make, model, year, weight, tripsincemaintenance, brand, name, colour, tripontheday,
                 isdriving=True, needsmaintenance=False):
        vehicle.__init__(self, make, model, year, weight, tripsincemaintenance, needsmaintenance=False)
        self.needsmaintenance = needsmaintenance
        self.isdriving = isdriving
        self.tripontheday = tripontheday
        self.brand = brand
        self.name = name
        self.colour = colour

    # def setdrive(self):
    # self.isdriving = True

    def counter(self):

        if self.isdriving == True:
            self.tripsincemaintenance = int(self.tripsincemaintenance) + int(self.tripontheday)
            print(self.tripsincemaintenance)
        else:
            self.tripsincemaintenance = int(self.tripsincemaintenance)
            print(self.tripsincemaintenance)

    def setmaintenance(self):
        if self.tripsincemaintenance > 100:
            self.needsmaintenance = True
            print(self.needsmaintenance)
        else:
            self.needsmaintenance = False
            print(self.needsmaintenance)

    def setstop(self):
        self.isdriving = False


car1 = car("abc", "chevy", 2008, 500, 0, "chevrolet", "cruze", "white", 1, True, False)
print(car1.make)
print(car1.model)
print(car1.year)
print(car1.weight)
car1.counter()
car1.setmaintenance()
car1 = car("abc", "chevy", 2008, 500, 1, "chevrolet", "cruze", "white", 0, False, False)
car1.counter()
car1.setmaintenance()
car1 = car("abc", "chevy", 2008, 500, 1, "chevrolet", "cruze", "white", 2, True, False)
car1.counter()
car1.setmaintenance()

car2 = car("xyz", "vpolo", 2015, 400, 60, "volkswagen", "polo", "white", 5, True, False)
print(car2.make)
print(car2.model)
print(car2.year)
print(car2.weight)
car2.counter()
car2.setmaintenance()
car2 = car("xyz", "vpolo", 2015, 400, 65, "volkswagen", "polo", "white", 40, True, False)
car2.counter()
car2.setmaintenance()
car2 = car("xyz", "vpolo", 2015, 400, 105, "volkswagen", "polo", "white", 1,  True, False)
car2.counter()
car2.setmaintenance()

car3 = car("jkl", "vitara", 2018, 480, 0, "suzuki", "breeza", "white", 0, False, False)
print(car3.make)
print(car3.model)
print(car3.year)
print(car3.weight)
car3.counter()
car3.setmaintenance()
car3 = car("jkl", "vitara", 2018, 480, 0, "suzuki", "breeza", "white", 97, True, False)
car3.counter()
car3.setmaintenance()
car3 = car("jkl", "vitara", 2018, 480, 97, "suzuki", "breeza", "white", 5, True, False)
car3.counter()
car3.setmaintenance()
