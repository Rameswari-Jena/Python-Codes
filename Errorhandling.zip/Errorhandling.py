Fav = "Senorita"
def FavSong():
    print('My favorite song is "senorita"')
try:
    print(int(Fav))
except:
    print("wrong input")
finally:
    FavSong()

def singer1_singer2(string1,string2):
    singer1 = string1
    singer2 = string2
    return singer1,singer2
try:
    artist1, artist2 = singer1_singer2("Shawn Mendes", "Camila Cabello")
except:
    print("cann't print local variable outside the function")
finally:
    print("sung by " + artist1 + " & " + artist2)


def genre(string):
    abc = string
    return abc
try:
    raise ValueError(123)
except:
    genre_song = genre("POP")
finally:
    print("It is a " + genre_song + " song")


def releaseYear(x,y):
    ry = x+y
    return ry
try:
    ry = "2019"
    print(ry)
except:
    print("cann't convert an integer to string")
finally:
    release_year = releaseYear(2000,19)
    print("It is released in the year: " + str(release_year))
