import random as r

word_list = ["elephant", "crow", "corona", "lockdown", "python", "job", "cloud", "rain", "clock", "pen", "two",
             "string"]


def get_word():
    word = r.choice(list(word_list))
    return word.upper()

def play(word):
    fill_the_word = "_" * len(word)
    guessed = False
    guessed_letters = []
    tries = 6
    print("Let's start the Game")
    print(Hangman(tries))
    print(fill_the_word)
    print("\n")
    while not guessed and tries > 0:
        guess = input("guess a letter or word: ").upper()
        if guess.isalpha():
            if guess in guessed_letters:
                print("you already guessed the letter")
            elif guess not in word:
                guessed_letters.append(guess)
                print("wrong guess")
                tries -= 1
                print(Hangman(tries))
            else:
                guessed_letters.append(guess)
                word_as_list = list(fill_the_word)
                indices = [i for i, letter in enumerate(word) if letter == guess]
                for index in indices:
                    word_as_list[index] = guess
                fill_the_word = "".join(word_as_list)
                print(fill_the_word)
                if "_" not in fill_the_word:
                    guessed = True

    if guessed:
        print("Congrats ! You won")
    else:
        print("sorry you are out of tries. Better Luck next time !")


def Hangman(tries):
    stages = ["""
                --------
                |      |
                |      O
                |     /|\
                |      |
                |     /|\
                """,
              """
                ---------
                |       |
                |       O
                |      /|\
                |       |
                |      /
                """,
              """
                ---------
                |       |
                |       O
                |      /|\
                |       |
                |
                """,
              """
                ---------
                |       |
                |       O
                |      /|
                |       |
                |
                """,
              """
                ---------
                |       |
                |       O
                |       |
                |       |
                |
                """,
              """
                ---------
                |       |
                |       O
                |
                |
                |
                """,
              """
                ---------
                |       |
                |       
                |
                |
                |
                """]
    return stages[tries]

def main():
    word = get_word()
    play(word)
    while input("play again: Y/N").upper() == "Y":
        word = get_word()
        play(word)

game = main()