note = input("file name: ")
import os
if os.path.exists(note):

    if input("want to read?: ") == "yes":
        f1 = open(note,"r")
        print(f1.read())

    elif input("want to delete and start over?: ") == "yes":
        os.remove(note)
        f2 = open(note,"w")
        for line in note:
            f2.write(input("start writing again: "))
            f2.write("\n")
        f2.close()
        f2 = open(note,"r")
        print(f2.read())
        f2.close()

    elif input("want to append? : ") == "yes":
        f3 = open(note,"r")
        print(f3.read())
        f3.close()
        f3 = open(note,"a")
        for line in note:
            f3.write(input("text:"))
            f3.write('\n')
        f3.close()
        f3 = open(note,"r")
        print(f3.read())
        f3.close()

    elif input("want to replace a line? : ") == "yes":
        y = int(input("which line you want to update ?: "))
        f4 = open(note,"r")
        lines = f4.readlines()
        print(lines)
        lines[y] = input("new line: ")
        lines[y] = lines[y] + "\n"
        print(lines)
        f4.close()
        f4 = open(note,"w")
        f4.writelines(lines)
        f4.close()
        f4 = open(note,"r")
        print(f4.read())
        f4.close()
    else:
        a = open(note,"r")
        print("The original text in this file:\n " + a.read())
        a.close()

else:
    f5 = open(note,"w")
    f5.write(input("Note: "))
    f5.close()
    f5 = open(note,"r")
    print(f5.read())
    f5.close()









