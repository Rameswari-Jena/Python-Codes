
def matrix(row,column):
#maximum width of terminal = 91
#maximum height of terminal =11
    if row < 11:
        for i in range(row):
            if i%2 == 0:
                if column < 91:
                    for j in range(1,column+1):
                        if j%2 != 0:
                            if j != column:
                                print(" ",end = " ")
                            else:
                                print(" ")
                        elif j != column:
                            print("|", end=" ")
                        else:
                            print("|")
                else:
                    print("Out of specified column range")
                    return False
                    break

            else:
                print("-" * 2 * column)
                continue
        return True
    else:
        print("out of specified row range")
        return False
a = matrix (7,20)
print(a)



