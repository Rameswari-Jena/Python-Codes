for num in range(1,101):

    if num == 1:
        print(str(num) + ": ")
    elif num % 15 == 0:
        print(str(num) + ": " + "fizzbuzz")
    elif num % 3 == 0:
        print(str(num) + (": ") + "fizz")
    elif num % 5 == 0:
         print(str(num) + ": " + "buzz")
    else:
        for i in range(2,num):
            if num % i == 0:
                print(str(num) + ": ")
                break
            else:
                print(str(num) + ": " + "prime")
                break

        #print(str(num) + ": " + "prime")














