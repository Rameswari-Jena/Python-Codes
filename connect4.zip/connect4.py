def matrix(draw):

    for r in range(12):
        if r % 2 == 0:             # 0,2,4,6,8,10
            for c in range(13):
                if c % 2 == 0:     # 0,2,4,6,8,10,12
                    usedcolumn = int(c / 2)
                    if c != 12:
                        print(draw[usedcolumn][r], end=" ")
                    else:
                        print(draw[usedcolumn][r])
                else:
                    if c != 12:
                        print(" ", end=" ")
                    else:
                        print(" ")
        else:
            for c in range(13):
                if c % 2 == 0:
                    if c != 12:
                        print("_", end=" ")
                    else:
                        print("_")
                else:
                    print(" ", end=" ")



player = 1
CF = [[" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "], [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "], [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "], [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "], [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "], [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "], [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "]]
print(CF)

while (True):
    print("Players Turn: ", player)
    column = int(input("please enter the column: "))
    row = 10
    if player == 1:

        if CF[column][row] == " ":
            CF[column][row] = "x"
            print(CF)
            matrix(CF)
            player = 2
        else:
            for n in range(2,11,2):
                row = 10
                row = row - n
                if CF[column][row] == " ":
                    CF[column][row] = "x"
                    print(CF)
                    matrix(CF)
                    player = 2
                    break
                else:
                    print("kuch bhi")

    elif player == 2:

        if CF[column][row] == " ":
            CF[column][row] = "o"
            print(CF)
            matrix(CF)
            player = 1
        else:
            for n in range(2,11,2):
                row = 10
                row = row - n
                if CF[column][row] == " ":
                    CF[column][row] = "o"
                    print(CF)
                    matrix(CF)
                    player = 1
                    break
                else:
                    print("kuch bhi")
    else:
        print("You are playing wrong game")




    #if draw[usedcolumn][r] == "x" and draw[usedcolumn][int(r) - 2] == "x" and draw[usedcolumn][int(r) - 4] == "x" and draw[usedcolumn][int(r) - 6] == "x":
        #print("player 1 is winner")
        #break
    #elif draw[usedcolumn][r] == "o" and draw[usedcolumn][int(r) - 2] == "o" and draw[usedcolumn][int(r) - 4] == "o" and draw[usedcolumn][int(r) - 6] == "o":
        #print("player 2 is winner")
        #break
    #elif draw[usedcolumn][r] == "x" and draw[int(usedcolumn) + 1][r] == "x" and draw[int(usedcolumn) + 2][r] == "x" and draw[int(usedcolumn) + 3][r] == "x":
        #print("player 1 is winner")
        #break
    #elif draw[usedcolumn][r] == "o" and draw[int(usedcolumn) + 1][r] == "o" and draw[int(usedcolumn) + 2][r] == "o" and draw[int(usedcolumn) + 3][r] == "o":
        #print("player 2 is winner")
        #break
    #elif draw[usedcolumn][r] == "x" and draw[int(usedcolumn) + 1][int(r) - 2] == "x" and draw[int(usedcolumn) + 2][int(r) - 4] == "x" and draw[int(usedcolumn) + 3][int(r) - 6] == "x":
        #print("player 1 is winner")
        #break
    #elif draw[usedcolumn][r] == "o" and draw[int(usedcolumn) + 1][int(r) - 2] == "o" and draw[int(usedcolumn) + 2][int(r) - 4] == "o" and draw[int(usedcolumn) + 3][int(r) - 6] == "o":
        #print("player 2 is winner")
        #break
    #else:
        #continue






