myFavSong = {"name":"senorita","singer":"Shawn Mendes","genre":"pop","releaseyear":2019,"repeat":10}
print(myFavSong)


while(True):
    for key in myFavSong:
        print(key + ": " + str(myFavSong[key]))
    break
def keycheck(key,value):
    while(True):
        if key in myFavSong:
            if value == myFavSong[key]:
                print(key + ": " + str(myFavSong[key]))
                print("True")
                break
            else:
                print("False")
                break
        else:
            print("False")
            break
keycheck("genre","pop")




