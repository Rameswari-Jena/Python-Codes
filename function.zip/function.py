#favsong = "Senorita"
#genre = "POP"
#Singer1, Singer2 = "Shawn Mendes", "Camila Cabello"
#ReleaseYear = 2019

def FavSong():
    print('My favorite song is "senorita"')
FavSong()

def singer1_singer2(string1,string2):
    singer1 = string1
    singer2 = string2
    return singer1,singer2
artist1,artist2 = singer1_singer2("Shawn Mendes","Camila Cabello")
print("sung by " + artist1 + " & " + artist2)

def genre(string):
    abc = string
    return abc
genre_song = genre("POP")
print("It is a " + genre_song + " song")

def releaseYear(x,y):
    ry = x+y
    return ry
release_year = releaseYear(2000,19)
print("It is released in the year: " + str(release_year))
