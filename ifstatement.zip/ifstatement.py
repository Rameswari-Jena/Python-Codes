def compare(x,y,z):

        if x == y and y == z:
                return True
        elif x == y or y == z or z == x:
                return True
        else:
                return False

statement1 = compare(2,5,7)
print(statement1)

statement2 = compare(8,4,"rilu")
print(statement2)

statement3 = compare(8,"rilu",8)
print(statement3)

statement4 = compare("rilu",5,"rilu")
print(statement4)

statement5 = compare(2.4,"rilu",2.4)
print(statement5)

