myUniqueList = []
print("unique list: " + str(myUniqueList))
myLeftovers =[]
print("leftover: " + str(myLeftovers))


def AddToRejectList(x):
    myLeftovers.append(x)
    print("False")

def AddValues(x):
        if x in myUniqueList:
            AddToRejectList(x)
            #myLeftovers.append(x)
            #print("False")
            #print("leftover: " + str(myLeftovers))
        else:
            myUniqueList.append(x)
            print("True")
            #print("unique list: " + str(myUniqueList))

AddValues(0.5)
AddValues([2,3,"rilu"])
AddValues(0.5)
AddValues([2,3,"rilu"])
AddValues("rilu")
AddValues([3,4])
AddValues(93)
AddValues(13)
AddValues(93)

print("unique list: " + str(myUniqueList))
print("leftovers: " + str(myLeftovers))
