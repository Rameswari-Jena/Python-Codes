title="Top song in my PLAYLIST"
print(title + " :")

name = "Rilu"
hobby = "I love listening to music"
print("I" + " am " + name)
print(hobby)

FavSong = "Senorita"
singer1, singer2 = "Shawn Mendes", "Camila Cabello"
print("My favorite song is " + FavSong)
print("It is sung by " + singer1 + " & " + singer2)

#The Song has gone gaga over billions of audiences all over the world.

DurationInMinutes = 3.15
ReleaseYear = 2019
genre ="POP"
print("Duration of the song is " + str(DurationInMinutes) + " min")
print("Released in the year " + str(ReleaseYear))
print("It is a " + genre + " song")

"""I love POP songs more than that of Jazz
I Think Most of you are as well..
If I am not wrong"""

Likes = 100
print("Likes till Dec2019 is " + str(Likes) + "k")
Likes = Likes + 80
print("Likes till Jan 1st week is " + str(Likes) + "k")
Likes += 3
print("Likes now is " + str(Likes) + "k")